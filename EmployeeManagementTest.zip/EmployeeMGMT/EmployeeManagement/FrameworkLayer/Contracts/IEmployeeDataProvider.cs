﻿using FrameworkLayer.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrameworkLayer.Contracts
{
    public interface IEmployeeDataProvider
    {
        public Task<bool> AddEmployee(EmployeeDTO employee);
        public IEnumerable<WorkerDTO> GetAllWorkers();
    }
}
