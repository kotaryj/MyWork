﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrameworkLayer.DTOs
{
    public record SupervisiorDTO: WorkerDTO
    {
        public decimal AnnualSalary { get; set; }
    }
}
