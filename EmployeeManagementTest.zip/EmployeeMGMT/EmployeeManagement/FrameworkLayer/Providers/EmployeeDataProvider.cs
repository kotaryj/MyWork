﻿using FrameworkLayer.Contracts;
using FrameworkLayer.DTOs;
using Microsoft.Extensions.Configuration;
using RepositoryLayer;
using RepositoryLayer.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrameworkLayer.Providers
{
    public class EmployeeDataProvider : IEmployeeDataProvider
    {
        DapperService ds = new DapperService();//has to be added by DI
        public async Task<bool> AddEmployee(EmployeeDTO employee)
        {
            Employee e = new Employee();//has to use autommapper from EmpDTo to Emp
            return await ds.AddAsync(e);
        }

        public IEnumerable<WorkerDTO> GetAllWorkers()
        {
            List<EmployeeDTO> e = new List<EmployeeDTO>(); //use ds.getAllEmp
            List<SupervisiorDTO> s = new List<SupervisiorDTO>();//use ds.getAll superviosr
            List<ManagerDTO> m = new List<ManagerDTO>();//use ds.getAll managers
            List<WorkerDTO> w = new List<WorkerDTO>();
            w.AddRange(e);
            w.AddRange(m);
            w.AddRange(s);
            return w;
        }
    }
}
