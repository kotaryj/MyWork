using FrameworkLayer.Contracts;
using FrameworkLayer.DTOs;
using FrameworkLayer.Providers;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeManagement.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class EmployeeController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

        private readonly ILogger<EmployeeController> _logger;
        IEmployeeDataProvider pro = new EmployeeDataProvider();

        public EmployeeController(ILogger<EmployeeController> logger)
        {
            _logger = logger;
        }

        [HttpPost(Name = "AddEmployee")]
        public async Task<IActionResult> AddEmployee(EmployeeDTO employee)
        {
            return Ok(pro.AddEmployee(employee));

        }
        [HttpGet(Name = "GetAllEmployyes")]
        public List<WorkerDTO> GetAllEmployyes()
        {
            return (List<WorkerDTO>)pro.GetAllWorkers();
        }
    }
}