using FrameworkLayer.Contracts;
using FrameworkLayer.DTOs;
using FrameworkLayer.Providers;
using Xunit.Sdk;

namespace EmployeeManagementTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1For_GetAllEmployees()
        {
            IEmployeeDataProvider pro = new EmployeeDataProvider();
            List<WorkerDTO> w = (List<WorkerDTO>)pro.GetAllWorkers();
            Assert.IsNotNull(w);
        }
    }
}