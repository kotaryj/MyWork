﻿using Dapper;
using Microsoft.Extensions.Configuration;
using RepositoryLayer.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryLayer
{
    public class DapperService
    {
        IDbConnection con;
        public DapperService(IConfiguration conf)//DI should be added interst of time not adding
        {
            con = new SqlConnection(conf.GetConnectionString("Consting"));
        }
        public async Task<bool> AddAsync(Employee emp)
        {
            string sql = "Insert command for interting into EMp and workers table";
            int ret=  await con.ExecuteAsync(sql);
            return ret>0;
        }
        public List<Employee> getAllEmp()
        {
            string sql = "Select * from dbo.Employees E join dbo.worker w on E.EmpId=w.Id";
            return (List<Employee>)con.Query<List<Employee>>(sql);
        }
        public List<Managercs> getAllMan()
        {
            string sql = "Select * from dbo.Managers E join dbo.worker w on E.ManagerID=w.Id";
            return (List<Managercs>)con.Query<List<Managercs>>(sql);
        }
        public List<Supervisor> getAllSup()
        {
            string sql = "Select * from dbo.Supervisor E join dbo.worker w on E.SupervisiorId=w.Id";
            return (List<Supervisor>)con.Query<List<Supervisor>>(sql);
        }
    }
}
