﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryLayer.Entities
{
    public class Employee
    {
        public int EmpId { get; set; }
        public decimal PayPerHour { get; set; }
    }
}
