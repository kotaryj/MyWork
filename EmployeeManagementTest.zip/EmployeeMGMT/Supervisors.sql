USE [EmployeeManagementDB]
GO

/****** Object:  Table [dbo].[Supervisors]    Script Date: 08/29/2023 01:35:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Supervisors](
	[SupervisorID] [int] NOT NULL,
	[AnnualSalary] [numeric](10, 2) NULL,
 CONSTRAINT [PK_Supervisors] PRIMARY KEY CLUSTERED 
(
	[SupervisorID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Supervisors]  WITH CHECK ADD  CONSTRAINT [FK_Supervisors_Workers] FOREIGN KEY([SupervisorID])
REFERENCES [dbo].[Workers] ([ID])
GO

ALTER TABLE [dbo].[Supervisors] CHECK CONSTRAINT [FK_Supervisors_Workers]
GO


