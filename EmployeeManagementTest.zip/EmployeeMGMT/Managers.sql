USE [EmployeeManagementDB]
GO

/****** Object:  Table [dbo].[Managers]    Script Date: 08/29/2023 01:35:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Managers](
	[ManagerID] [int] NOT NULL,
	[AnnualSalary] [numeric](10, 2) NULL,
	[MaxExpenseAmount] [numeric](10, 2) NULL,
 CONSTRAINT [PK_Managers] PRIMARY KEY CLUSTERED 
(
	[ManagerID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Managers]  WITH CHECK ADD  CONSTRAINT [FK_Managers_Workers] FOREIGN KEY([ManagerID])
REFERENCES [dbo].[Workers] ([ID])
GO

ALTER TABLE [dbo].[Managers] CHECK CONSTRAINT [FK_Managers_Workers]
GO


